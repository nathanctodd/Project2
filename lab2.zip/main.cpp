#include <iostream>
#include <vector>
#include <string>
#include "Parser.h"
#include "Token.h"


int main(int argc, char *argv[]) {

    vector<Token> tokens;

    tokens.push_back(Token(ID,"Ted",2));
   // tokens.push_back(Token(LEFT_PAREN,"(",2));
    tokens.push_back(Token(ID,"Ted",2));
    tokens.push_back(Token(COMMA,",",2));
    tokens.push_back(Token(ID,"Zed",2));
    tokens.push_back(Token(RIGHT_PAREN,")",2));



     Parser p = Parser(tokens);
     p.scheme();

}