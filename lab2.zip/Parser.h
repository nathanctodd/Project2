

#include <iostream>
#include <string>
#include <vector>
#include "Token.h"

using namespace std;

class Parser {
    
    private:
        vector<Token> tokenList;
        
    public:
        Parser(const vector<Token> tokens) {

            tokenList = tokens;

        }

        TokenType tokenType() const {
            return tokenList.at(0).getType();
        }

        void advanceToken() {
            tokenList.erase(tokenList.begin());
        }

        void throwError() {
            cout << "Error" << endl;
        }

        void match(TokenType t) {
            cout << "Match: " << t << endl;
            if (tokenType() == t)
                advanceToken();
            else    
                throwError();
        }


        void idList() {

            if (tokenType() == COMMA) {
                match(COMMA);
                match(ID);
                idList();
            } else {
                //Lambda
            }
        }

        void scheme() {
            if (tokenType() == ID) {
                match(ID);
                match(LEFT_PAREN);
                match(ID);
                idList();
                match(RIGHT_PAREN);
            } else {
                throwError();
            }
        }



};